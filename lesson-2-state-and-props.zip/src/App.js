import "./index.css";
import React from "react";
import ReactDOM from "react-dom";

function Hi(props) {
  return (
    <div className="practice">
      <h1> {props.title}</h1>
      <p>{<strong>props.body</strong>}</p>
      <div className="content">
        <img src={props.imageUrl} alt="nft" />
      </div>
    </div>
  );
}

ReactDOM.render(
  <Hi
    title="NFT's web"
    body="I am going to be a badass developer"
    imageUrl="https://media.newyorker.com/photos/61016c1c7a2a603b3075c7b8/master/pass/chayka-boredapeclub.jpg"
  />,
  document.querySelector("#root")
);

export default Hi;
