import "./index.css";
import React from "react";
import ReactDOM from "react-dom";

function Gate(props) {
  const [isOpen] = React.useState(false);
  return <div className="pratice">Gate is {isOpen ? "open" : "close"}</div>;
}

ReactDOM.render(<Gate />, document.querySelector("#root"));

export default Gate;
