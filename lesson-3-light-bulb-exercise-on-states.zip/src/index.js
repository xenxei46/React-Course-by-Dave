import React from "react";
import ReactDOM from "react-dom";
import "./index.css";

function Room() {
  const [isLit, setLit] = React.useState(true);
  const brightness = isLit ? "lit" : "dark";
  const [temp] = React.useState(true);
  return (
    <div className={`room ${brightness}`}>
      <h1>The room is {isLit ? "lit" : "dark"}</h1>
      <p>Temperature is {temp ? "72%" : "0%"}</p>
      <button onClick={() => setLit(!isLit)}>Switch</button>
      <button onClick={() => setLit(true)}>on</button>
      <button onClick={() => setLit(!setLit)}>off</button>
    </div>
  );
}

ReactDOM.render(<Room />, document.querySelector("#root"));

export default Room;
